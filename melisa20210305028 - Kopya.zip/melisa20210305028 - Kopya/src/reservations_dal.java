import java.sql.*;
import java.util.ArrayList;

public class reservations_dal {
    // for MsSQL Server
    // mssql.connector.j-8.3.0
    String user = "Yusuf Kaval", pass = "yusufmelisa";
    String conUrl = "jdbc:sqlserver://localhost:1433;encrypt=false;integratedSecurity=false;databaseName=flight;user=sa;password=1234;";


    public void Test() {
        try {
            Connection conn = DriverManager.getConnection(conUrl, user, pass);
            System.out.println("Connected to MsSql server.....");
        } catch (
                SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void ListToConsole() {
        String cmd = "SELECT `ReservationID`,`UserID`,`FlightID`,`ReservationDate` FROM `reservation`";

        try (Connection conn = DriverManager.getConnection(conUrl, user, pass);) {
            Statement statement = conn.createStatement();
            ResultSet res = statement.executeQuery(cmd);

            int say = 0;
            int ReservationID;
            String UserID, FlightID, ReservationDate;

            System.out.println("result set ready");
            while (res.next()) {
                ReservationID = res.getInt(1);
                UserID = res.getString(1);
                FlightID = res.getString(1);
                ReservationDate = res.getString(1);



                System.out.printf("ReservationID= %d%n, UserID= %s%n, FlightID= %s%n, ReservationDate= %s%n",  ReservationID, UserID, FlightID, ReservationID);
                say++;
            }
            System.out.println("End of List.");
            res.close();

            //System.out.println("Connected to MsSql server.....");
        } catch (
                SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    public void addCartInfo(CartInfo cartInfo) {
        try (Connection conn = DriverManager.getConnection(conUrl, user, pass)) {
            String sql = "INSERT INTO CartInfo (Name, CardId, ExpirationDate, CCV) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, cartInfo.name);
            statement.setInt(2, cartInfo.cardId);
            statement.setInt(3, cartInfo.expirationDate);
            statement.setInt(4, cartInfo.ccv);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   /* public ArrayList<CartInfo> getCartInfo() {
        ArrayList<CartInfo> cartInfoList = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(conUrl, user, pass)) {
            String sql = "SELECT Name, CardId, ExpirationDate, CCV FROM CartInfo";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                CartInfo cartInfo = new CartInfo();
                cartInfo.name = resultSet.getString("Name");
                cartInfo.cardId = resultSet.getInt("CardId");
                cartInfo.expirationDate = resultSet.getInt("ExpirationDate");
                cartInfo.ccv = resultSet.getInt("CCV");
                cartInfoList.add(cartInfo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cartInfoList;
    }
}
*/
    public ArrayList<reservations> Getreservations() {
        ArrayList<reservations> rlist = new ArrayList<>();

        String cmd = "SELECT `ReservationID`,`UserID`,`FlightID`,`ReservationDate`, FROM `reservations`";
        reservations r;
        try (Connection conn = DriverManager.getConnection(conUrl, user, pass);)
        {
            Statement statement = conn.createStatement();
            ResultSet res = statement.executeQuery(cmd);

            while(res.next()) {
                r = new reservations();

                r.ReservationID = res.getInt(1);
                r.UserID = res.getString(1);
                r.FlightID = res.getString(1);
                r.ReservationDate = res.getString(1);


                rlist.add(r);
            }
            res.close();

            //System.out.println("Connected to MsSql server.....");
        } catch (
                SQLException e) {
            System.out.println(e.getMessage());
        }
        return rlist;
    }
}

