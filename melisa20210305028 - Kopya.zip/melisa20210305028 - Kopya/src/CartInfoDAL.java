import java.sql.*;
import java.util.ArrayList;

public class CartInfoDAL {
    static String user = "Yusuf Kaval";
    static String pass = "yusufmelisa";
    static String conUrl = "jdbc:mssql://localhost/tickets";

    public void addCartInfo(CartInfo cartInfo) {
        try (Connection conn = DriverManager.getConnection(conUrl, user, pass)) {
            String sql = "INSERT INTO CartInfo (Name, CardId, ExpirationDate, CCV) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, cartInfo.name);
            statement.setInt(2, cartInfo.cardId);
            statement.setInt(3, cartInfo.expirationDate);
            statement.setInt(4, cartInfo.ccv);
            statement.executeUpdate();
            System.out.println("CartInfo added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding CartInfo: " + e.getMessage());
        }
    }

    public ArrayList<CartInfo> getCartInfo() {
        ArrayList<CartInfo> cartInfoList = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(conUrl, user, pass)) {
            String sql = "SELECT Name, CardId, ExpirationDate, CCV FROM CartInfo";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                CartInfo cartInfo = new CartInfo();
                cartInfo.name = resultSet.getString("Name");
                cartInfo.cardId = resultSet.getInt("CardId");
                cartInfo.expirationDate = resultSet.getInt("ExpirationDate");
                cartInfo.ccv = resultSet.getInt("CCV");
                cartInfoList.add(cartInfo);
            }
            System.out.println("CartInfo retrieved successfully.");
        } catch (SQLException e) {
            System.out.println("Error retrieving CartInfo: " + e.getMessage());
        }

        return cartInfoList;
    }



}
