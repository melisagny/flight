public class CartInfo {
    public String name;
    public int cardId;
    public int expirationDate;
    public int ccv;

}
