import java.sql.*;
import java.util.ArrayList;

public class users_dal {
    // for MsSQL Server
    // mssql.connector.j-8.3.0
    String user = "Yusuf Kaval", pass = "yusufmelisa";
    String conUrl = "jdbc:mssql://localhost/tickets";

    public void Test() {
        try {
            Connection conn = DriverManager.getConnection(conUrl, user, pass);
            System.out.println("Connected to MsSql server.....");
        } catch (
                SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void ListToConsole() {
        String cmd = "SELECT `UserID`,`UserName`,`Password`,`EmailAdress`,FullName`,`PhoneNumber` FROM `users`";

        try (Connection conn = DriverManager.getConnection(conUrl, user, pass);) {
            Statement statement = conn.createStatement();
            ResultSet res = statement.executeQuery(cmd);

            int say = 0;
            int UserID;
            String UserName, Password, EmailAdress, FullName, PhoneNumber;

            System.out.println("result set ready");
            while (res.next()) {
                UserID = res.getInt(1);
                UserName = res.getString(1);
                Password = res.getString(1);
                EmailAdress = res.getString(1);
                FullName = res.getString(1);
                PhoneNumber = res.getString(1);

                System.out.printf("UserID= %d%n, UserName= %s%n, Password= %s%n, EmailAdress= %s%n, FullName= %s&n, PhoneNumber= %s&n", UserID, UserName, Password, EmailAdress, FullName, PhoneNumber);
                say++;
            }
            System.out.println("End of List.");
            res.close();

            //System.out.println("Connected to MsSql server.....");
        } catch (
                SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public ArrayList<users> Getusers() {
        ArrayList<users> ulist = new ArrayList<>();

        String cmd = "SELECT `UserID`,`UserName`,`Password`,`EmailAdress`,FullName`,`PhoneNumber`, FROM `users`";
        users u;
        try (Connection conn = DriverManager.getConnection(conUrl, user, pass);)
        {
            Statement statement = conn.createStatement();
            ResultSet res = statement.executeQuery(cmd);

            while(res.next()) {
                u = new users();

                u.UserID = res.getInt(1);
                u.UserName = res.getString(1);
                u.Password = res.getString(1);
                u.EmailAdress = res.getString(1);
                u.FullName = res.getString(1);
                u.PhoneNumber = res.getString(1);

                ulist.add(u);
            }
            res.close();

            //System.out.println("Connected to MsSql server.....");
        } catch (
                SQLException e) {
            System.out.println(e.getMessage());
        }
        return ulist;
    }
}

