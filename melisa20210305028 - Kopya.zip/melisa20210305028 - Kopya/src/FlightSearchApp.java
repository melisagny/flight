import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FlightSearchApp extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private List<String> purchasedTickets;
    private Connection connection;

    public FlightSearchApp() {
        setTitle("Login Screen");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        purchasedTickets = new ArrayList<>();

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(new JLabel()); // Boş alan
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Kullanıcı adı ve şifre doğrulaması yapılabilir

                if (username.equals("yusuf kaval") && password.equals("yusufmelisa")) {
                    dispose(); // Giriş başarılı ise bu pencereyi kapat
                    showMainScreen(); // Ana ekranı göster
                } else {
                    JOptionPane.showMessageDialog(FlightSearchApp.this, "Hatalı kullanıcı adı veya şifre!", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        try {
            // Veritabanı bağlantısını oluştur
            connection = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;encrypt=false;integratedSecurity=false;databaseName=flight;user=sa;password=1234;");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void showMainScreen() {
        JFrame mainScreen = new JFrame("Main Monitor");
        mainScreen.setSize(800, 600);
        mainScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel flightPanel = new JPanel(new GridLayout(2, 5));

        for (int i = 1; i <= 10; i++) {
            JButton flightButton = new JButton("Flight " + i);
            flightButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Uçuş seçildiğinde ödeme ekranına yönlendir
                    showDetails(flightButton.getText()); // Uçuş numarasını parametre olarak gönder
                }
            });
            flightPanel.add(flightButton);
        }

        JButton logoutButton = new JButton("Log out");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainScreen.dispose(); // Ana ekrandan çıkış yap
                FlightSearchApp.this.setVisible(true); // Giriş ekranını yeniden göster
            }
        });

        mainScreen.add(flightPanel, BorderLayout.CENTER);
        mainScreen.add(logoutButton, BorderLayout.SOUTH);
        mainScreen.setVisible(true);
    }

    private void showDetails(String ticket) {
        JFrame paymentScreen = new JFrame("Payment Screen");
        paymentScreen.setSize(400, 300);
        paymentScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel nameLabel = new JLabel("Name Surname:");
        JTextField nameField = new JTextField();
        JLabel cardNumberLabel = new JLabel("Card Number:");
        JTextField cardNumberField = new JTextField();
        JLabel expiryLabel = new JLabel("Expiration Date (MM/YY):");
        JTextField expiryField = new JTextField();
        JLabel ccvLabel = new JLabel("CCV:");
        JTextField ccvField = new JTextField();

        JButton payButton = new JButton("Pay");

        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ödeme bilgilerini al
                String name = nameField.getText();
                String cardNumber = cardNumberField.getText();
                String expiry = expiryField.getText();
                String ccv = ccvField.getText();

                // Ödeme bilgilerini veritabanına kaydet
                savePaymentInfo( name, cardNumber, expiry, ccv);

                JOptionPane.showMessageDialog(paymentScreen, "Payment Successful!", "Successful", JOptionPane.INFORMATION_MESSAGE);
                paymentScreen.dispose(); // Ödeme ekranını kapat
                showMainScreen(); // Ana ekrana geri dön
            }
        });

        JPanel paymentPanel = new JPanel(new GridLayout(5, 2));
        paymentPanel.add(nameLabel);
        paymentPanel.add(nameField);
        paymentPanel.add(cardNumberLabel);
        paymentPanel.add(cardNumberField);
        paymentPanel.add(expiryLabel);
        paymentPanel.add(expiryField);
        paymentPanel.add(ccvLabel);
        paymentPanel.add(ccvField);
        paymentPanel.add(new JLabel()); // Boş alan
        paymentPanel.add(payButton);

        paymentScreen.add(paymentPanel);
        paymentScreen.setVisible(true);
    }

    private void savePaymentInfo( String name, String cardNumber, String expiry, String ccv) {
        try {
            String query = "INSERT INTO CartInfo (Name, CardId, ExpirationDate, CCV) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, cardNumber);
            statement.setString(3, expiry);
            statement.setString(4, ccv);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                FlightSearchApp loginForm = new FlightSearchApp();
                loginForm.setVisible(true);
            }
        });
    }
}
