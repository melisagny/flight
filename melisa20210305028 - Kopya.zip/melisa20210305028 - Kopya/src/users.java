public class users {

    public int UserID ;
    public String UserName,Password, EmailAdress,FullName,PhoneNumber;
}
