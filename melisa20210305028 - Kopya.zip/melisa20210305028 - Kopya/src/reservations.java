public class reservations {

    public int ReservationID ;
    public String UserID,FlightID, ReservationDate;
}

